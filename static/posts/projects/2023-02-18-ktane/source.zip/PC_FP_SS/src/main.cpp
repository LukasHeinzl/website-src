#include <Arduino.h>

#define NUM_RGB 4
#define COL_BLUE 0
#define COL_YELLOW 1
#define COL_GREEN 2
#define COL_RED 3

#define PORT_CHECK 6

int rgbPorts[] = {3, 5, 4, 2};
int btnPorts[] = {9, 11, 10, 8};

int sequence[] = {-1, -1, -1, -1, -1, -1, -1};
int sequenceLength = 7;
int currentSequenceLength = 0;
bool complete = false;
bool online = false;
bool started = false;
int numInputs = 0;

void generateSequence();
void displaySequence();
int btnToCol(int btnPort);
void check(int col);
void resetLeds();
void handleSerialCommunication();

void setup()
{
  Serial.begin(57600);
  pinMode(PORT_CHECK, OUTPUT);

  for (int i = 0; i < NUM_RGB; i++)
  {
    pinMode(rgbPorts[i], OUTPUT);
    pinMode(btnPorts[i], INPUT_PULLUP);
  }
}

void loop()
{
  handleSerialCommunication();

  if (!online || !started || complete)
  {

    return;
  }

  for (int i = 0; i < NUM_RGB; i++)
  {
    // inverse logic because of pullup
    if (digitalRead(btnPorts[i]) == LOW)
    {
      check(btnToCol(btnPorts[i]));
      delay(100);
    }
  }
}

void generateSequence()
{
  // set seed to random floating value
  randomSeed(analogRead(0));

  for (int i = 0; i < sequenceLength; i++)
  {
    sequence[i] = (int)random(4);
  }

  currentSequenceLength = 0;
  complete = false;
  numInputs = 0;
  digitalWrite(PORT_CHECK, LOW);
}

void displaySequence()
{
  delay(500);

  for (int i = 0; i <= currentSequenceLength; i++)
  {
    digitalWrite(rgbPorts[sequence[i]], HIGH);
    delay(300);
    digitalWrite(rgbPorts[sequence[i]], LOW);
    delay(300);
  }
}

int btnToCol(int btnPort)
{
  for (int i = 0; i < NUM_RGB; i++)
  {
    if (btnPorts[i] == btnPort)
    {
      return i;
    }
  }

  return -1;
}

void check(int col)
{
  digitalWrite(rgbPorts[col], HIGH);
  delay(200);
  digitalWrite(rgbPorts[col], LOW);
  delay(200);

  if (sequence[numInputs] == col)
  {
    numInputs++;

    if (numInputs > currentSequenceLength)
    {
      currentSequenceLength++;
      numInputs = 0;

      if (currentSequenceLength == sequenceLength)
      {
        complete = true;
        Serial.write((uint8_t)1); // write code 1 to signal module completion
        digitalWrite(PORT_CHECK, HIGH);
      }
      else
      {
        displaySequence();
      }
    }
  }
  else
  {
    numInputs = 0;
    displaySequence();
  }
}

void resetLeds()
{
  for (int i = 0; i < NUM_RGB; i++)
  {
    digitalWrite(rgbPorts[i], LOW);
  }

  digitalWrite(PORT_CHECK, LOW);
}

void handleSerialCommunication()
{
  if (Serial.available())
  {
    int code = Serial.read();

    // we are not online, initiate handshake
    if (!online)
    {
      if (code == 21)
      {
        // magic value 21 read, send module id
        Serial.write((uint8_t)0);
        online = true;
        
      }
    }
    else
    {
      // we are online - code can start or end the game OR go offline
      if (code == 0)
      {
        // code 0 - we go offline, turn off all LEDs
        online = false;
        started = false;
        complete = false;
        resetLeds();
      }
      else if (code == 1)
      {
        // code 1 - start game
        started = true;
        generateSequence();
        displaySequence();
      }
      else if (code == 2)
      {
        // code 2 - end game
        started = false;
        complete = false;
        resetLeds();
      }
    }
  }
}