#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal.h>

#define PORT_CHECK 10
#define PORT_BTN1 8
#define PORT_BTN2 9

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

// first entry is the word to guess, the other 5 are the possible characters at every position
char possibleWords[15][6][6] = {
    {"about", "zyal", "obtx", "pqog", "uaie", "skth"},
    {"abase", "zyal", "obtx", "dage", "hfts", "feat"},
    {"again", "alsi", "sjgu", "ajld", "sdiv", "sdon"},
    {"agile", "alsi", "sjgu", "lvoi", "cdul", "djke"},
    {"aging", "alsi", "sjgu", "lvoi", "axnp", "gznj"},
    {"fifth", "jlxf", "juis", "aftj", "thso", "ahsk"},
    {"first", "jlxf", "juis", "ahtr", "ksdq", "bvct"},
    {"fired", "jlxf", "juis", "ahtr", "edhz", "gbdh"},
    {"folio", "kxhf", "ojst", "fdlq", "dloi", "cokw"},
    {"found", "kxhf", "ojst", "aucn", "hunk", "lkbd"},
    {"thing", "lstn", "kshr", "isnc", "lnsw", "csng"},
    {"think", "lstn", "kshr", "isnc", "lnsw", "bkzd"},
    {"third", "lstn", "kshr", "isnc", "fgrl", "gfud"},
    {"today", "lstn", "dsjo", "lsdi", "aceq", "daky"},
    {"total", "lstn", "dsjo", "gtkl", "afhi", "dfgl"}};

int possibleWordCount = 15;
int wordLength = 5;
int possibleCharCount = 4;
int wordIdx = -1;
int charIdx = -1;
char selectedChars[5] = {'\0', '\0', '\0', '\0', '\0'};
int selectedCharPos[5] = {0, 0, 0, 0, 0};
bool complete = false;
bool online = false;
bool started = false;

void chooseWord();
void rerender();
void cycleCurrentChar();
void submit();
void checkWord();
void handleSerialCommunication();

void setup()
{
  Serial.begin(57600);

  // set seed to random floating value
  randomSeed(analogRead(0));

  pinMode(PORT_CHECK, OUTPUT);
  pinMode(PORT_BTN1, INPUT_PULLUP);
  pinMode(PORT_BTN2, INPUT_PULLUP);
  lcd.begin(16, 2);
  lcd.print("Offline");

  digitalWrite(PORT_CHECK, LOW);
}

void loop()
{
  handleSerialCommunication();

  if (!online || !started || complete)
  {
    return;
  }

  // inverse logic because of pullup
  if (digitalRead(PORT_BTN1) == LOW)
  {
    cycleCurrentChar();
    delay(200);
  }
  else if (digitalRead(PORT_BTN2) == LOW)
  {
    submit();
    delay(200);
  }
}

void chooseWord()
{
  wordIdx = random(possibleWordCount);
  charIdx = 0;

  for (int i = 0; i < wordLength; i++)
  {
    // set first character of every position
    // i + 1 because 0 is the actual word
    selectedChars[i] = possibleWords[wordIdx][i + 1][0];
    selectedCharPos[i] = 0;
  }
}

void rerender()
{
  lcd.clear();
  lcd.setCursor(0, 0);

  for (int i = 0; i < wordLength; i++)
  {
    lcd.print(selectedChars[i]);
  }

  if (charIdx == wordLength)
  {
    lcd.print("   SUBMIT");
    lcd.setCursor(charIdx + 3, 1);
    lcd.print("^^^^^^");
  }
  else
  {
    lcd.setCursor(charIdx, 1);
    lcd.print('^');
  }
}

void cycleCurrentChar()
{
  if (charIdx >= wordLength)
  {
    return;
  }

  selectedCharPos[charIdx]++;
  selectedCharPos[charIdx] %= possibleCharCount;
  // charIdx + 1 because 0 is the actual word
  selectedChars[charIdx] = possibleWords[wordIdx][charIdx + 1][selectedCharPos[charIdx]];
  rerender();
}

void submit()
{
  if (charIdx == wordLength)
  {
    checkWord();
    return;
  }

  charIdx++;
  rerender();
}

void checkWord()
{
  bool failed = false;

  for (int i = 0; i < wordLength; i++)
  {
    if (possibleWords[wordIdx][0][i] != selectedChars[i])
    {
      failed = true;
      break;
    }
  }

  if (failed)
  {
    lcd.clear();
    lcd.setCursor(5, 0);
    lcd.print("WRONG!");
    delay(2000);
    chooseWord();
    rerender();
    return;
  }

  lcd.clear();
  lcd.setCursor(4, 0);
  lcd.print("CORRECT!");

  lcd.setCursor(5, 1);
  lcd.print(">");
  lcd.print(possibleWords[wordIdx][0]);

  digitalWrite(PORT_CHECK, HIGH);
  complete = true;
  Serial.write((uint8_t)1); // write code 1 to signal module completion
}

void handleSerialCommunication()
{
  if (Serial.available())
  {
    int code = Serial.read();

    // we are not online, initiate handshake
    if (!online)
    {
      if (code == 21)
      {
        // magic value 21 read, send module id
        Serial.write((uint8_t)2);
        online = true;
        lcd.clear();
        lcd.print("Waiting");
      }
    }
    else
    {
      // we are online - code can start or end the game OR go offline
      if (code == 0)
      {
        // code 0 - we go offline, turn off all LEDs
        online = false;
        started = false;
        complete = false;
        lcd.clear();
        lcd.print("Offline");
        digitalWrite(PORT_CHECK, LOW);
      }
      else if (code == 1)
      {
        // code 1 - start game
        started = true;
        digitalWrite(PORT_CHECK, LOW);
        chooseWord();
        rerender();
      }
      else if (code == 2)
      {
        // code 2 - end game
        started = false;
        complete = false;
        lcd.clear();
        lcd.print("Waiting");
        digitalWrite(PORT_CHECK, LOW);
      }
    }
  }
}