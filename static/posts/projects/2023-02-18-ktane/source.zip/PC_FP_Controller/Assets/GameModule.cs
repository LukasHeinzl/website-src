using System.IO.Ports;

public class GameModule
{

    private int moduleId;
    private SerialPort port;
    private ModuleState state = ModuleState.ONLINE;

    public enum ModuleState
    {
        ONLINE, IN_GAME, COMPLETE
    }

    public GameModule(int moduleId, SerialPort port)
    {
        this.moduleId = moduleId;
        this.port = port;
    }

    public override string ToString()
    {
        return "GameModule(" + moduleId + ", " + port.PortName + ", " + state + ")";
    }

    public int GetId() => moduleId;
    public ModuleState GetState() => state;

    public void Start()
    {
        if (!port.IsOpen)
        {
            return;
        }

        port.Write(new byte[] { 1 }, 0, 1); // write code 1 to start game
        state = ModuleState.IN_GAME;
    }

    public void Stop()
    {
        if (!port.IsOpen)
        {
            return;
        }

        port.Write(new byte[] { 2 }, 0, 1); // write code 2 to stop game
        state = ModuleState.ONLINE;
    }

    public void Close()
    {
        if (!port.IsOpen)
        {
            return;
        }

        port.Write(new byte[] { 0 }, 0, 1); // write code 0 to turn module offline
        port.Close();
    }

    public void Update()
    {
        if (state != ModuleState.IN_GAME)
        {
            return;
        }

        if (port.BytesToRead > 0)
        {
            var buffer = new byte[1];
            int bytesRead = port.Read(buffer, 0, buffer.Length);

            if (bytesRead != 1)
            {
                return;
            }

            if (buffer[0] == 1)
            {
                // code 1 signals module completion
                state = ModuleState.COMPLETE;
            }
        }
    }
}
