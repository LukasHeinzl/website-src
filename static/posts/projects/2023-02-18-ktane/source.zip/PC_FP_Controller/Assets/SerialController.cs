using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;
using System;

public class SerialController : MonoBehaviour
{

    private List<GameModule> gameModules = new List<GameModule>();

    void Start()
    {
        foreach (var portName in SerialPort.GetPortNames())
        {
            InitiateHandshake(portName);
        }
    }

    private void Update()
    {
        gameModules.ForEach(m => m.Update());
    }

    private void InitiateHandshake(string portName)
    {
        var port = new SerialPort(portName, 57600);

        if (port.IsOpen)
        {
            return;
        }

        port.Open();
        port.ReadTimeout = 1;

        if (!port.IsOpen)
        {
            return;
        }

        var buffer = new byte[] { 21 };
        port.Write(buffer, 0, 1); // Write magic value 21 to start handshake
        port.ReadTimeout = 500; // for handshake we wait 0.5s until we give up

        while (port.BytesToWrite > 0) { }

        try
        {
            int bytesRead = port.Read(buffer, 0, buffer.Length); // Read a single byte in response (ID of GameModule)

            if (bytesRead != 1)
            {
                return;
            }
        }
        catch (Exception)
        {
            return;
        }

        port.ReadTimeout = 1; // for regular communcation we basically do not wait
        gameModules.Add(new GameModule(buffer[0], port));
    }

    private void OnDestroy()
    {
        gameModules.ForEach(m => m.Close());
    }

    public void StartGame()
    {
        gameModules.ForEach(m => m.Start());
    }

    public void StopGame()
    {
        gameModules.ForEach(m => m.Stop());
    }

    public bool AllComplete()
    {
        foreach (var m in gameModules)
        {
            if (m.GetState() != GameModule.ModuleState.COMPLETE)
            {
                return false;
            }
        }

        return true;
    }

    public GameModule GetModuleById(int id)
    {
        return gameModules.Find(m => m.GetId() == id);
    }
}
