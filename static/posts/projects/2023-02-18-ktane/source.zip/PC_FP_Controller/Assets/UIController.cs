using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    [SerializeField]
    private SerialController comCon;

    [SerializeField]
    private GameObject startStopButton;

    [SerializeField]
    private Text timerText;

    [SerializeField]
    private float maxTimer = 120f; // 2 minutes to solve all games

    private Image btnImage;
    private Text btnText;
    private bool started;
    private float timeRemaining;

    private void Start()
    {
        btnImage = startStopButton.GetComponent<Image>();
        btnText = startStopButton.GetComponentInChildren<Text>();
    }

    private void Update()
    {
        if (started)
        {
            int min = (int)(timeRemaining / 60);
            int sec = (int)(timeRemaining % 60);
            timerText.text = min.ToString("00") + ":" + sec.ToString("00");
            timerText.color = Color.Lerp(Color.red, Color.green, timeRemaining / maxTimer);
            timeRemaining -= Time.deltaTime;
            HandleGameOver(comCon.AllComplete());
        }
    }

    public void HandleControlButton()
    {
        if (started)
        {
            HandleGameOver(true);
        }
        else
        {
            comCon.StartGame();
            timeRemaining = maxTimer;
            started = true;
        }

        UpdateStartStopButton();
    }

    private void UpdateStartStopButton()
    {
        btnImage.color = started ? Color.red : Color.green;
        btnText.text = started ? "Stop Games" : "Start Games";
    }

    private void HandleGameOver(bool force = false)
    {
        if (timeRemaining > 0f && !force)
        {
            return;
        }

        started = false;
        UpdateStartStopButton();

        if (comCon.AllComplete())
        {
            timerText.text = "You won!";
            timerText.color = Color.green;
        }
        else
        {
            timerText.text = "Failed!";
            timerText.color = Color.red;
        }

        comCon.StopGame();
    }

}
