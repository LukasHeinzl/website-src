using UnityEngine;
using UnityEngine.UI;

public class GameModuleRenderer : MonoBehaviour
{
    [SerializeField]
    private int moduleId;

    [SerializeField]
    private SerialController comCon;

    [SerializeField]
    private GameObject onlineUI;

    [SerializeField]
    private Text statusText;

    private GameModule module;
    private bool isOnline;
    private bool isInitialised;

    // Update is called once per frame
    void Update()
    {
        if (!isInitialised)
        {
            module = comCon.GetModuleById(moduleId);
            isOnline = module != null;
            onlineUI.SetActive(isOnline);

            if (!isOnline)
            {
                statusText.text = "OFFLINE";
                statusText.color = Color.red;
            }

            isInitialised = true;
        }

        if (!isOnline)
        {
            return;
        }

        if (module.GetState() == GameModule.ModuleState.COMPLETE)
        {
            statusText.text = "COMPLETE";
            statusText.color = Color.green;
        }
        else if (module.GetState() == GameModule.ModuleState.IN_GAME)
        {
            statusText.text = "NOT COMPLETE";
            statusText.color = Color.red;
        }
        else
        {
            statusText.text = "WAITING";
            statusText.color = Color.white;
        }
    }
}
