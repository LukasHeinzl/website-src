#include <Arduino.h>

#define RGB_RED 6
#define RGB_GREEN 7
#define RGB_BLUE 8
#define PORT_CHECK 9
#define PORT_BTN 10
#define PORT_FAIL 11

// 3 states, 2 values per state
// first is the LED color to show, the second is the countdown value after which the button must be released
int possibleStates[3][2] = {{RGB_RED, 3}, {RGB_GREEN, 8}, {RGB_BLUE, 13}};
int stateCount = 3;

int state = -1;
unsigned long targetTime = -1;
bool isLit = false;
int count = 0;

bool online = false;
bool started = false;
bool complete = false;

void lightRGB(int);
void handleSerialCommunication();

void setup()
{
  Serial.begin(57600);

  // set seed to random floating value
  randomSeed(analogRead(0));

  pinMode(PORT_CHECK, OUTPUT);
  pinMode(PORT_FAIL, OUTPUT);
  pinMode(RGB_RED, OUTPUT);
  pinMode(RGB_GREEN, OUTPUT);
  pinMode(RGB_BLUE, OUTPUT);
  pinMode(PORT_BTN, INPUT_PULLUP);
}

void loop()
{
  handleSerialCommunication();

  if (!online || !started || complete)
  {
    return;
  }

  // inverse logic because of pullup
  if (digitalRead(PORT_BTN) == LOW)
  {
    if (state == -1)
    {
      state = random(stateCount);
      count = 0;
      isLit = true;
      targetTime = millis() + 250;
      lightRGB(possibleStates[state][0]);
    }
    else
    {
      if (millis() >= targetTime)
      {
        isLit = !isLit;
        count += isLit ? 1 : 0;
        targetTime = millis() + 500;

        lightRGB(isLit ? possibleStates[state][0] : -1);
      }
    }
  }
  else
  {
    lightRGB(-1);

    if (isLit && state > -1 && state < stateCount && count == possibleStates[state][1])
    {
      complete = true;
      Serial.write((uint8_t)1); // write code 1 to signal module completion
      digitalWrite(PORT_CHECK, HIGH);
      delay(1000);
    }
    else
    {
      if (state != -1)
      {
        state = -1;
        targetTime = -1;
        count = 0;

        for (int i = 0; i < 3; i++)
        {
          digitalWrite(PORT_FAIL, HIGH);
          delay(300);
          digitalWrite(PORT_FAIL, LOW);
          delay(300);
        }
      }
    }
  }
}

void lightRGB(int color)
{
  digitalWrite(RGB_RED, RGB_RED == color ? HIGH : LOW);
  digitalWrite(RGB_GREEN, RGB_GREEN == color ? HIGH : LOW);
  digitalWrite(RGB_BLUE, RGB_BLUE == color ? HIGH : LOW);
}

void handleSerialCommunication()
{
  if (Serial.available())
  {
    int code = Serial.read();

    // we are not online, initiate handshake
    if (!online)
    {
      if (code == 21)
      {
        // magic value 21 read, send module id
        Serial.write((uint8_t)1);
        online = true;
      }
    }
    else
    {
      // we are online - code can start or end the game OR go offline
      if (code == 0)
      {
        // code 0 - we go offline, turn off all LEDs
        online = false;
        started = false;
        complete = false;
      }
      else if (code == 1)
      {
        // code 1 - start game
        started = true;
        complete = false;
      }
      else if (code == 2)
      {
        // code 2 - end game
        started = false;
        complete = false;
      }

      isLit = false;
      state = -1;
      targetTime = -1;
      digitalWrite(PORT_CHECK, LOW);
    }
  }
}